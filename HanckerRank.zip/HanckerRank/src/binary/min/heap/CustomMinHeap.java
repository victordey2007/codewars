package binary.min.heap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.PriorityQueue;

public class CustomMinHeap{
	private ArrayList<Integer> data1=new ArrayList<Integer>();
	HashMap<Integer,Integer> data =new HashMap<Integer,Integer>();
	int size=0;
	
	// this method insert in BInary heap and reorder  the element to keep the minheap property not violated
	public void insert( int element )
	{
		data1.add(element);
		orderRoot(this.size);
		this.size=size+1;
		
		for(int j=0;j<data1.size() && j!=1;j++)
		{

		}
		
	}
	
	public void orderRoot(int index)
	{
		if(index<=0)
			return ;
		
		if(data1.get(index)<data1.get(index/2))
				{
			  		int temp=data1.get(index/2);
			  		data1.set(index/2,data1.get(index));
			  		data1.set(index,temp);
			  		orderRoot(index/2);
				}
		
	}
	
	public int peekMin() {
		
		int temp=data1.get(0);
		data1.set(0,data1.get(size-1));
		data1.remove(size-1);
		this.size=size-1;
		heapify(0);
		return temp;
		
		
		
	}
	public void heapify(int index)
	{
		if(index*2+1>=size)
			return;
		
		if(data1.get(index*2+1)<data1.get(index))
		{
			int temp=data1.get(index);
			data1.set(index,data1.get(index*2+1));
			data1.set(index*2+1,temp);
			
			heapify(index*2+1);
		}
	}
	
	
}
