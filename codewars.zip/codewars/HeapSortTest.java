package codewars;
import static org.junit.Assert.*;

import org.junit.Test;

public class HeapSortTest {
	@Test
	public void test1() {
		int[] val= {2,1};
		int[] input = {2,1};
		assertEquals(val, HeapSort.heapSort(input));
	}
}
