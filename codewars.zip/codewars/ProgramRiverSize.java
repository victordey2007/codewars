import java.util.*;

class Program {

	public String tournamentWinner(ArrayList<ArrayList<String>> competitions, ArrayList<Integer> results) {
		// Write your code here.
		HashMap<String, Integer> data = new HashMap<String, Integer>();

		for (int i = 0; i < competitions.size(); i++) {
			String homeTeam = competitions.get(i).get(0);
			String awayTeam = competitions.get(i).get(1);

			if (results.get(i) == 1) {
				if (data.containsKey(homeTeam)) {
					int val = data.get(homeTeam);
					data.put(homeTeam, val + 1);

				} else {
					data.put(homeTeam, 1);

				}

			} else if (results.get(i) == 0) {
				if (data.containsKey(awayTeam)) {
					int val = data.get(awayTeam);
					data.put(awayTeam, val + 1);

				} else {
					data.put(awayTeam, 1);

				}

			}

		}
		int value = Integer.MIN_VALUE;
		String key = "";
		for (String test : data.keySet()) {
			if (data.get(test) > value) {

				value = data.get(test);
				key = test;

			}

		}

		return key;
	}
}
