package array.manipulation;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class Solution {

	// Complete the arrayManipulation function below.
	static long arrayManipulation(int n, int[][] queries) {
		int[] a = new int[n];
		int max = Integer.MIN_VALUE;
		for (int i = 0; i < queries.length; i++) {
			
			
			for (int j = queries[i][0] - 1; j < queries[i][1]; j++) {
				a[j] = a[j] + queries[i][2];
				if (a[j] > max)
					max = a[j];
			}
		}

		return max;

	}

	static long arrayManipulation1(int n, int[][] queries) {
		int[] a = new int[n];
		int max = Integer.MIN_VALUE;
		for (int[] temp : queries) {
			a[temp[0] - 1] = temp[2];
			if (temp[1] != a.length)
	            a[temp[1]] -= temp[2];
		}

		max = 0;
		int itt = 0;
		System.out.println(a);
		for (int qt : a) {
			itt += qt;
			if (itt > max)
				max = itt;
		}
		return max;

	}

	private static final Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) throws IOException {
		// BufferedWriter bufferedWriter = new BufferedWriter(new
		// FileWriter(System.getenv("OUTPUT_PATH")));

		String[] nm = scanner.nextLine().split(" ");

		int n = Integer.parseInt(nm[0]);

		int m = Integer.parseInt(nm[1]);

		int[][] queries = new int[m][3];

		for (int i = 0; i < m; i++) {
			String[] queriesRowItems = scanner.nextLine().split(" ");
			scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

			for (int j = 0; j < 3; j++) {
				int queriesItem = Integer.parseInt(queriesRowItems[j]);
				queries[i][j] = queriesItem;
			}
		}

		long result = arrayManipulation(n, queries);
		long result1 = arrayManipulation1(n, queries);
		System.out.println(String.valueOf(result));
		System.out.println(String.valueOf(result1));
		// bufferedWriter.newLine();

		// bufferedWriter.close();

		scanner.close();
	}
}
