package binary.min.heap;

import java.util.ArrayList;

public class Solution {
	
 public static void main (String str[])
 {
	 int [] a= {1,2,3,4,5,6};
	 
	System.out.println(0-6);
	 	
			
					}
 
}