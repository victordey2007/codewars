package codewars;

import java.util.*;
public class RemovedNumbers {
	
	public static List<long[]> removNb(long n) {
		// your code
	 	long sum=(n*(n+1))/2;
  LinkedList<long[]> numbers = new LinkedList<long[]>();
    System.out.println(sum); 
    
    for(long a=1;a<n;a++)
      {
      double b= (sum-a)/(double)(a+1);
      
     if (b <= n && b % 1 == 0) 
        {
        long[] nb= new long[2];
        nb[0]=a;
        nb[1]=(long)b;
        numbers.add(nb);
      }
      
    }
      
    return numbers; 
    
	}
}

