package codewars;
import java.util.*;
public class BraceChecker {

  public boolean isValid(String braces) {
    // Add code here
   System.out.println(braces);
    Stack<String> localStack=new Stack<String>();
    String leftBraces="({[";
    String rightBraces=")}]";
    HashMap<String,String> RightToLeft= new HashMap<String,String>();
    RightToLeft.put(")","(");
    RightToLeft.put("}","{");
    RightToLeft.put("]","[");
    
    for(int i=0;i<braces.length();i++)
      {
       String val=String.valueOf(braces.charAt(i));
       if(rightBraces.contains(val))
         {     
         if(localStack.isEmpty() || !RightToLeft.get(val).equals(localStack.pop()))
               return false; 
          }
      else
           localStack.add(val);
        
      
    }
    
    return true;
  }

}