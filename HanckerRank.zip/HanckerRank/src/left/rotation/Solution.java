package left.rotation;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class Solution {


    public static void main(String[] args) throws IOException {
       

        int[] a = {2 ,1, 5, 3, 4,6};
        minimumBribes(a);
    
    
    }
    
    
    static void minimumBribes(int[] q) {
    	for(int i=0 ;i<(q.length)-2 ;i++)
        {
           System.out.println(q[i]+":"+q[i+1]);
    		if(q[i]-q[i+1]>2) 
             System.out.println("Too chaotic");
             
        }

}
}