package minimum.swap;

//Java program to find
//minimum number of swaps
//required to sort an array
import java.util.*;
import java.io.*;

class SolutionBinarySeach 
{
	 static int minimumSwaps(int[] arr) {
	      int[] sortArr= Arrays.copyOf(arr,arr.length);
	      Arrays.sort(sortArr);
	      int count =0;
	      
	
	      for(int k =0;k<arr.length;k++)
	      {
	    	int index= binarySearchSort(sortArr,0,arr.length,arr[k]);
	    	
	    	  while(index!=k)
	    	  {
	    		 int temp= arr[index];
	    		 arr[index]=arr[k];
	    		 arr[k]=temp;
	    		 index= binarySearchSort(sortArr,0,arr.length,arr[k]);
	    		 count++;
	    	  }
	      }
	        System.out.println(count);
	        return count;
	    }
	  
	   public static  int binarySearchSort(  int[] items, int startIndex,int endIndex,int searchItem)
		  {
			  
			 
			 
			  
			  if(items!=null && items.length>=endIndex && endIndex>=startIndex)
			  {
				  int mid=(endIndex-startIndex)/2+startIndex;
				
				  if(items[mid]==searchItem)
					  return mid;
				  else if(searchItem < items[mid])
					  return binarySearchSort(items,startIndex,mid,searchItem);
				  else 
					  return  binarySearchSort(items,mid,items.length,searchItem);
			  }
			  
			  return -1;
		  }
		 
 // Driver program to test 
 // the above function
 public static void main(String[] args) 
                          throws Exception
 {
     int[] a
         = { 101, 758, 315, 730, 472, 
                      619, 460, 479 };
     int n = a.length;
     // Output will be 5
     System.out.println(minimumSwaps(a));
     System.out.println(a);
 }
}