package codewars;

import java.util.ArrayList;

/*
 *  Write a funtion which will take input  "string": "1921680" 
 *  give all possible cobination of valid ip address
 *  where individual block is in range of 0-255 inclusive 
 *  same output for 1921680
 *  3700100
 * 
 */
public class ValidIpAdressCombination {

	public static void main(String str[]) {
		validIPAddresses("3700100");
	}

	public static ArrayList<String> validIPAddresses(String string) {

		ArrayList<String> allIps = new ArrayList<String>();
		validIPAddresses(string, "", 0, allIps);

		return allIps;
	}

	public static void validIPAddresses(String orgString, String ip, int blockPos, ArrayList<String> allIps) {
		if (blockPos == 4 && ip.length() - 4 == orgString.length()) {

			System.out.println(ip.substring(1));
			allIps.add(ip.substring(1));
		} else {
			String sub = orgString.substring(ip.length() - blockPos);

			for (int i = 1; i <= sub.length(); i++) {
				String tempString = sub.substring(0, i);
				System.out.println(tempString.substring(0, 1));
				if (tempString.length() >= 2 && tempString.substring(0, 1).equals("0")) {
					break;
				}
				int value = Integer.parseInt(tempString);

				if (value >= 0 && value <= 255) {
					validIPAddresses(orgString, ip + "." + tempString, blockPos + 1, allIps);
				} else
					break;

			}

		}

	}
}
