package binary.sort;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Solution {
	
	  public static void main(String[] args) throws IOException {
	       

	        int[] a = {6,5,1,3, 2,4,8,100,200,430,9,76};
	        int count =0;
	        Arrays.sort(a);
	      
	        
	  
	      
	        	 count= binarySearchSort(a,0,a.length,430);
	        	 System.out.println(count);
	    
	      
	    }

	
	  
	  
	  
	  
	  
	  
	  
	  
	  public static  int binarySearchSort(  int[] items, int startIndex,int endIndex,int searchItem)
	  {
		  
		 
		 
		  
		  if(items!=null && items.length>=endIndex && endIndex>=startIndex)
		  {
			  int mid=(endIndex-startIndex)/2+startIndex;
			  System.out.println(mid);
			  if(items[mid]==searchItem)
				  return mid;
			  else if(searchItem < items[mid])
				  return binarySearchSort(items,startIndex,mid,searchItem);
			  else 
				  return  binarySearchSort(items,mid,items.length,searchItem);
		  }
		  
		  return -1;
	  }
	 
	  
		  
	  
	  class Item{
		  
		  int position ;
		  int value;
		  Item(int position, int value)
		  {
			  this.position=position;
			  this.value=value;
		  }
	  }
	  
}
