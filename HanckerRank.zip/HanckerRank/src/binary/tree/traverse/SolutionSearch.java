package binary.tree.traverse;

public class SolutionSearch {
	
	// SEARCH BINARY TREE BY VALUE COMPARISON WHERE IN THIS TREE LEFT<=ROOT AND  RIGHT>ROOT, TREE IS NOT min-HEAP TREE
	// IT WILL CHECK IS THE PROVIDED ELEMENT=ROOT THEN RETURN TRUE
	 //IF ROOT.LEFT == VALUE OR ROOT.RIGHT=VALUE RETURN TRUE
	public static boolean searchElement(Node root,int val)
	{
		if(root.getKey()==val
		||
		(root.getLeft()!=null &&  root.getLeft().getKey()==val)
		||
		(root.getRight()!=null &&  root.getRight().getKey()==val))
			return true;
		
		
		if(root.getLeft()!=null &&  val< root.getKey())
			return searchElement( root.getLeft(),val);
		
		if(root.getRight()!=null &&  val > root.getKey())
			return searchElement( root.getRight(),val);	
		
		
		return false;
	}
	public static void main(String str[]) {
		int[] data = { 1000, 12, 3, 100, 300, 500, 600 };

		Node root =new Node(data[0]);;
		for(int i=1;i<data.length;i++)
		{
			SolutionInsert.buildOridinaryHeapFromArray(root, data[i]);
		}
		
		System.out.println(searchElement(root,300));
	}
}
