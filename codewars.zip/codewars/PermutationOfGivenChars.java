package codewars;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class PermutationOfGivenChars {
	
	public static void main (String str [])
	{
		
		char[] elements= {'a'};
		
		
	 HashSet<String> allPemutations=new HashSet<String>();	
	 getAllPossiblePermutation(elements,0,allPemutations);
	
	 List<String> list = new ArrayList<String>(allPemutations);
	 System.out.println(allPemutations);
	}

	private static void getAllPossiblePermutation(char[] elements, int pos, HashSet<String> allPemutations) {
					
		if(pos==elements.length-1)
			return ;
		
		for(int l=0;l<elements.length;l++)
		{
			char[] elementsTem=elements;
			char temp=elementsTem[l];
			elementsTem[l]=elementsTem[pos];
			elementsTem[pos]=temp;
			allPemutations.add(String.valueOf(elementsTem));
			getAllPossiblePermutation(elementsTem,pos+1,allPemutations);
			
			
			
				
			
		}
		
		
	}

}
