package sorting.comparator;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Solution {

    public static void main(String[] args) {
       
    	
    	
    	
    	Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();

        Player[] player = new Player[n];
        
        Checker checker = new Checker();
        
        for(int i = 0; i < n; i++){
            player[i] = new Player(scan.next(), scan.nextInt());
        }
        scan.close();
        Player[] player1 = player.clone();
        Player[] player2 = player.clone();
        Arrays.sort(player, checker);
        for(int i = 0; i < player.length; i++){
            System.out.printf("%s %s\n", player[i].name, player[i].score);
        }
        
		/*
		 * Solution.sort(player1 ,checker);
		 * 
		 * for(int i = 0; i < player1.length; i++){ System.out.printf("%s %s\n",
		 * player1[i].name, player1[i].score); }
		 */
        
        
      
		
	
		 for(int i = 0; i < player2.length; i++){
	            System.out.printf("%s %s\n", player2[i].name, player2[i].score);
	        }
	        
        
    }
    
    
    //  create your custom sorting alog using traditional merger sort
        public  static  void sort(Object [] data, Comparator c)
    {
    	
    	int low=0;
    	int high=data.length;
    	for(int i=low;i<high;i++)
    	{
    		for(int j=i;j>low && c.compare(data[j-1], data[j])>0;j--)
    		{
    			Object temp=data[j];
    			data[j]=data[j-1];
    			data[j-1]=temp;
    			
    			
    		}
    	}
    	
    	
    }
        
       
    	
}