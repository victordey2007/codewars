package sorting.comparator;

import java.util.Comparator;

class Checker implements Comparator<Player> {
  	// complete this method
	public int compare(Player a, Player b) {
    if(a.getScore() < b.getScore() )
    return 1;
    else if(a.getScore() > b.getScore() )
        return -1;
   else 
     return a.getName().compareTo(b.getName());
    
    }
}