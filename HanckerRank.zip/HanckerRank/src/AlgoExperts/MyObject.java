package AlgoExperts;

public class MyObject {
	private int number;
	
	public MyObject(int number)
	{
		this.number=number;
		
	}	
	public boolean equals(MyObject obj) {
	        return (obj.number == this.number);
	    }
	
	@Override
	public int hashCode() {
		if(number==1 ||number==0 )
			return 11;
		else
			return super.hashCode();
		
	}
	public void delete() throws Throwable {
		this.finalize();
	}

}
