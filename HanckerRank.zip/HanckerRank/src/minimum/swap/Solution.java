package minimum.swap;

//Java program to find
//minimum number of swaps
//required to sort an array
import java.util.*;
import java.io.*;

class Solution 
{
	 static int minimumSwaps(int[] arr) {
	      int[] sortArr= Arrays.copyOf(arr,arr.length);
	      Arrays.sort(sortArr);
	      int count =0;
	      for(int i=0;i<arr.length;i++)
	      {
	          if(arr[i]!=sortArr[i])
	          {
	              count++;
	             int index=indexof(arr,sortArr[i]) ;
	             int temp=arr[index];
	             arr[index]=arr[i];
	             arr[i]=temp;
	          }
	          
	      } 
	             
	        return count;
	    }
	   static int indexof(int arr[],int val)
	   {
	    for(int j=0 ;j<arr.length;j++)
	    {
	        if(arr[j]==val)
	            return j;
	            
	    }    
	    return -1;
	   } 
	    
  
 // Driver program to test 
 // the above function
 public static void main(String[] args) 
                          throws Exception
 {
     int[] a
         = { 101, 758, 315, 730, 472, 
                      619, 460, 479 };
     int n = a.length;
     // Output will be 5
     System.out.println(minimumSwaps(a));
     System.out.println(a);
 }
}