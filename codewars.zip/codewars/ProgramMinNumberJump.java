package codewars;

import java.util.*;



class ProgramMinNumberJump {

	
	public static void main(String[] args) {
	
		int [] a= {3, 4, 2, 1, 2, 3, 7, 1, 1, 1, 3};
		minNumberOfJumps(a);
		
	}
	public static int minNumberOfJumps(int[] array) {
    // Write your code here.
    int index=0;
		int tmpindex=0;
		int val=0;
		int count=0;
		
		while(index<array.length)
		{
			
	
			val=index+array[index];
				System.out.println("index"+index); 
						 System.out.println("val"+val);
					for(int j=index+1;j<=index+array[index] && j<array.length;j++)
					{
						
					
						if(j+array[j]>val )
						{
							tmpindex=j;
							val=j+array[j];
							
							
						}
					}
				if(val<=index+array[index])
				{
						index=index+array[index];;
					
				}
			else
				index=tmpindex;
		 System.out.println("--------------");
			count++;
		
		}
		
		return count;
  }
}
