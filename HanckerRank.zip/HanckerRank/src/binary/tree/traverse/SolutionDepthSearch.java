package binary.tree.traverse;

import java.util.HashMap;

public class SolutionDepthSearch {
	
	public  static void printElementTogetherSameDepth(Node root,int depth,HashMap<Integer,String> values)
	
	
	{
		if(values.get(depth)!=null)
		{
			values.put(depth, values.get(depth)+","+root.getKey());
			
		}
		else
			values.put(depth, root.getKey()+"");
			
		if(root.getLeft()!=null)
			printElementTogetherSameDepth(root.getLeft(),depth+1,values);
		if(root.getRight()!=null)
			printElementTogetherSameDepth(root.getRight(),depth+1,values);
		
	}
	
	public static void main(String str[]) {
		int[] data = { 1000, 12, 3, 100, 300, 500, 600 };

		Node root =new Node(data[0]);;
		for(int i=1;i<data.length;i++)
		{
			SolutionInsert.buildOridinaryHeapFromArray(root, data[i]);
		}
		
		HashMap<Integer,String> values=new HashMap<Integer,String>();
		
		printElementTogetherSameDepth(root,0,values);
		
		System.out.println(values);
		
	}
	

}
