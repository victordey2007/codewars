package codewars;

import java.util.Stack;

/*
 * You are given an array (which will have a length of at least 3, but could be very large) containing integers. The array is either entirely comprised of odd integers or entirely comprised of even integers except for a single integer N. Write a method that takes the array as an argument and returns this "outlier" N.

Examples
[2, 4, 0, 100, 4, 11, 2602, 36]
Should return: 11 (the only odd number)

[160, 3, 1719, 19, 11, 13, -21]
Should return: 160 (the only even number)
 */
public class SolutionParityOutlier {
	
	public static void main (String str[])
	{
		
		 int[] exampleTest1 = {2,6,8,-10,3}; 	
		 FindTheParityOutlier(exampleTest1);
		  char e='z';
		  int aschii=e;
		  Stack<String> localStack=new Stack<String>();
		  localStack.
		System.out.println(aschii);
	}

	public static int FindTheParityOutlier(int[] integers)
	{
		  boolean  evenFlag=false;
		  int oddCOunt=0;
		  int evenCount=0;
		    for(int i=0;i<3;i++)
		    {
		      if(integers[i] %2==0)
		        evenCount++;
		      else
		        oddCOunt++;
		         
		  }
		    if(evenCount>oddCOunt)
		      evenFlag=true;
		    
		    
		    for(int i=0;i<integers.length;i++)
		      {
		        
		        if(evenFlag && integers[i]%2!=0 )
		            return integers[i];
		        
		          if(!evenFlag && integers[i]%2==0 ) 
		               return integers[i];
		    }
		    
		    
		    
		  return 0;
		
	}
}
