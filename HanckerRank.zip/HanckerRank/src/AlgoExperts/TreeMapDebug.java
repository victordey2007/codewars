package AlgoExperts;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.util.TreeMap;
import java.util.Vector;

public class TreeMapDebug {
	
	public static void main (String str[])
	{
		Map<String ,String > treeMap=new HashMap<String,String>();
		
		treeMap.put("FB", "VICTOR");/// has code same 
		treeMap.put("FF", "LIPIKA");
		treeMap.put("GG", "Arinjoy");
		treeMap.put("Ea", "Gauranga");//has code same 
		
		System.out.println("FB : "+hash("FB"));
		System.out.println("FF : "+hash("FF"));
		System.out.println("Ea : "+hash("Ea"));
		System.out.println("GG : "+hash("GG"));
		treeMap.keySet().iterator().forEachRemaining(act->{
			System.out.println(act);		});
			}

	
	 static final int hash(String key) {
	        int h;
	        return (key == null) ? 0 : (h = key.hashCode()) ^ (h >>> 16);
	    }
}
