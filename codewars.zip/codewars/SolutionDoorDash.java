package codewars;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;



public class SolutionDoorDash {

   public static List<Meeting>  getMeetingsList(List<Meeting> meeting ,int dutation,int startTime,int endTime )
   {
   
       
     
      
       meeting.add(0, new Meeting(Integer.MIN_VALUE, startTime));
       meeting.add(meeting.size(), new Meeting(endTime, Integer.MAX_VALUE));
       Collections.sort(meeting,new MeetingComp());
       System.out.println(meeting);
       List<Meeting> meetingSec=new ArrayList<Meeting>();
        
       
        for(int i=0;i<meeting.size();i++)
       {
          if(meeting.get(i).startTime>endTime)
        	  break;
        	if(meeting.get(i).startTime>startTime && meeting.get(i).startTime-startTime>dutation )
                {
                    Meeting tempSlots =new Meeting();
                    tempSlots.startTime=startTime;
                    tempSlots.endTime=meeting.get(i).startTime;
                    meetingSec.add(tempSlots);
                    
                    
                    
                }
           startTime=meeting.get(i).endTime;
       }
        System.out.println("------------------");
      
        for(Meeting meet:meetingSec) {
     	   System.out.println("startTime:"+ meet.startTime);
     	   System.out.println("End:"+ meet.endTime);
       	 
        } 
              
         
          
         return meetingSec;  
       }
       
       
 



static class Meeting {
  int startTime;
  int endTime;    
  public Meeting()
  {
	  this.startTime=0;
	  this.endTime=0;
	  
	  
  }
   public Meeting(int startTime,int endTime)
   {
	   this.startTime=startTime;
	   this.endTime=endTime;
   }
    
   
@Override
public String toString() {
	return "this.startTime: "+this.startTime +"this.endTime: "+this.endTime;
}  
}    
static class MeetingComp implements Comparator<Meeting> {
  int startTime;
  int endTime;    
    
    @Override
    public int compare(Meeting obj1, Meeting obj2) {
        if(obj1.startTime>obj2.startTime)
            return 1;
        else if(obj1.startTime<obj2.startTime)
        return -1;
        else return 0;
        
    }
    
    
}           
       
       

      
    public static void main(String args[] ) throws Exception {
        
    //	 [3,20], [-2, 0], [0,2], [16,17], [19,23], [30,40], [27, 33]
        Meeting m=new Meeting();
        m.startTime=3;
        m.endTime=20;
        
        Meeting m1=new Meeting();
        m1.startTime=-2;
        m1.endTime=0;
        
        Meeting m2=new Meeting();
        m2.startTime=0;
        m2.endTime=2;
        
        Meeting m3=new Meeting();
        m3.startTime=16;
        m3.endTime=17;
        
        Meeting m4=new Meeting();
        m4.startTime=19;
        m4.endTime=23;
        
        Meeting m5=new Meeting();
        m5.startTime=30;
        m5.endTime=40;
        
        Meeting m6=new Meeting();
        m6.startTime=27;
        m6.endTime=33;
        
        
        
        List<Meeting> meeting =new ArrayList<Meeting>();
        meeting.add(m);
        meeting.add(m1);
        meeting.add(m2);
        meeting.add(m3);
        meeting.add(m4);
        
        meeting.add(m5);
       meeting.add(m6);
       
        
        getMeetingsList(meeting,2,-5,27);
    }
}