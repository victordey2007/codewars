package codewars;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class CombinationProblems {

	public  static void main(String str[])
	{
		
	
		char []input={'b','a','c','d'};
		
		HashSet<String> resp=GetAllCombination(input);
		HashSet<String> tt=new HashSet<String> ();
		System.out.println(resp);
		
			System.out.println(GetAllCombinationWithRecur(input));
	
	}
	
	
	public static ArrayList<String>   GetAllCombinationWithRecur(char [] inputChars){
		
		ArrayList<String> data1=new ArrayList<String>();
		if(inputChars.length==0)
		{
			System.out.println(Arrays.toString(inputChars));
			data1.add("[]");
			return data1 ;
		}
		char firsElement=inputChars[0];
		inputChars=Arrays.copyOfRange(inputChars,1, inputChars.length);
		ArrayList<String>  data=GetAllCombinationWithRecur(inputChars);
		for(String dataElement:data)
		{
			data1.add(dataElement);
			data1.add(dataElement+firsElement);
			
		}
		System.out.println(firsElement);
		return data1;
	}

	public static HashSet<String>  GetAllCombination(char [] inputChars)
	{
		HashSet<String> resp= new HashSet<String>();
		
		resp.add("[]");
	
		
		for(int i=0;i<inputChars.length;i++)
		{
		ArrayList<String> datatmp= new ArrayList<String>();
	    String val=String.valueOf(inputChars[i]);
		resp.forEach(action-> {
			
			datatmp.add(val+action);
			
		});
		
		datatmp.forEach(action->{
			resp.add(action);
			
		});
		}
		
		return resp;
	
		
		
	}
	
}
