package codewars;

import java.util.*;

import org.junit.platform.commons.util.StringUtils;

public class KatanextSmaller {
	public static long nextSmaller(long n) {
		long number = -1;
		Long[] digits = getAlldigits(n);
	    int maxValuePostion = -1;
		int minValuePostion = -1;
		
		StringUtils
		// get the x where digits[i] >digits[i+1]
		for (int i = digits.length - 2; i >= 0; i--) {
			if (digits[i] > digits[i + 1]) {
				maxValuePostion = i;
				break;
			}

		}
		// now get the minimum value start from the postion x
		if (maxValuePostion == -1)
			return -1;

		for (int i = maxValuePostion + 1; i <= digits.length - 1; i++) {
			if (maxValuePostion == 0 && digits[i] == 0)
				continue;
			if ((minValuePostion == -1 && digits[i] < digits[maxValuePostion])
					|| minValuePostion != -1 && digits[i] < digits[minValuePostion])
				minValuePostion = i;

		}
		if (minValuePostion == -1)
			return -1;
		// swap the elements

		Long temp = digits[minValuePostion];
		digits[minValuePostion] = digits[maxValuePostion];
		digits[maxValuePostion] = temp;

		// seperate element two arrays after X and till X
		Long[] digits1 = Arrays.copyOfRange(digits, 0, maxValuePostion + 1);
		Long[] digits2 = Arrays.copyOfRange(digits, maxValuePostion + 1, digits.length);

		// Array asc sort after max element postion so tha we can get he minimum number
		Arrays.sort(digits2, Collections.reverseOrder());

		arrayCopy(digits, digits1, 0);
		arrayCopy(digits, digits2, digits1.length);

		System.out.println(Arrays.toString(digits));
		return generateLongFromDigits(digits);
	}

	public static void arrayCopy(Long[] destination, Long[] inputArray, int start) {
		for (int i = 0; i < inputArray.length; i++)
			destination[i + start] = inputArray[i];

	}

	public static Long[] getAlldigits(long n) {
		String val = String.valueOf(n);
		Long[] digits = new Long[val.length()];
		for (int i = 0; i < val.length(); i++) {
			digits[i] = Long.parseLong(String.valueOf(val.charAt(i)));

		}
		StringBuilder input1 = new StringBuilder("");
		
		return digits;

	}

	public static Long generateLongFromDigits(Long[] digits) {
		Long decimal = 1L;
		Long sum = 0L;
		for (int i = digits.length - 1; i >= 0; i--) {
			sum = sum + digits[i] * decimal;
			decimal = decimal * 10;
		}

		return sum;
	}

}