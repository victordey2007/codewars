package codewars;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class TestTreeMap {
public static void main(String[] args) {
	int seconds=15731080;
	 int  days=(seconds%(365*24*60*60))/(24*60*60);
	 int a='a';
	 int z='z';
	 "".trim()
	 int A='A';
	 int Z='Z';
	 char l='p';
	 System.out.println(l>=a && l<=z);
	 System.out.println(l>=A && l<=Z);
	 String[] smallStrings;
	 smallStrings[0].substring(beginIndex, endIndex)
}
