package codewars;

import java.util.*;
public class RomanNumerals {
    private static HashMap<Integer,String> map=new HashMap<Integer,String>();
   static {
     map.put(1,"I");
     map.put(5,"V");
     map.put(10,"X");
     map.put(50,"L");
     map.put(100,"C");
     map.put(500,"D");
     map.put(1000,"M");
} 
 
  public static String toRoman(int n) {
    
   
    
    ArrayList<Integer> digits= getRomanRenderedDigits(int n)   ;
    System.out.println(digits) ;
    return "I";
  }
  public static ArrayList<Integer>  getRomanRenderedDigits(int n) 
    {
    int decimal=1;
    ArrayList<Integer> digits=new ArrayList<Integer>();
    String value=String.valueOf(n);
    for(int i=value.length()-1;i>=0;i--)
      {
      int temp=Integer.parseInt(String.valueOf(value.charAt(i)));
      if(temp!=0)
        {
        digits.add(temp*decimal);
        
      }
      decimal=decimal*10;
    }
    
    return digits;
    
  }
  
  public static int fromRoman(String romanNumeral) {
    
    
    
    
    return 1;
  }
  
  
}