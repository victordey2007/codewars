package codewars;

import java.util.*;

class ProgramZigjag {
	public static List<Integer> zigzagTraverse(List<List<Integer>> array) {
		// Write your code here.
		boolean flagdown = true;
		boolean flagTop = true;
		int total = array.get(0).size() * array.size();
		int count = 1;
		int row = 0;
		int col = 0;
		int height = array.size() - 1;
		int weidth = array.get(0).size() - 1;
		List<Integer> resp = new ArrayList<Integer>();
		resp.add(array.get(row).get(col));

		while (count < total) {
			if (flagdown) {
				if (row < height)
					row++;
				else
					col++;
				count++;
				resp.add(array.get(row).get(col));
				flagdown = false;
			} else {
				flagdown = true;
				if (col < weidth)
					col++;
				else
					row++;
				count++;
				resp.add(array.get(row).get(col));

			}
			if (flagTop) {
				while (row > 0 && col < weidth) {
					row--;
					col++;
					count++;
					resp.add(array.get(row).get(col));

				}
				flagTop = false;

			} else {
				flagTop = true;
				while (col > 0 && row < height) {
					row++;
					col--;
					count++;
					resp.add(array.get(row).get(col));
				}
			}
		}
		return resp;
	}
}
