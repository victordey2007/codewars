package codewars;

import java.util.Arrays;

public class MergeSort {
	public static void main(String[] args) {
		int [] a= {7,5,1,100,8,5,5,4,2,6,3};
		
		a=mergeSort(a)	  ;
		System.out.println(a);
	
	} 
	
	public static int [] mergeSort(int []a)
	{
		if(a.length==1)
			return a ;
		else if(a.length==2)
		{
			swap(a);
			return a;
		}
		
		else {
		int mid=0;
		if(a.length%2==0)
			mid=a.length/2-1;
		else
			mid=a.length/2;
				
		
		int []leftData=mergeSort(Arrays.copyOfRange(a, 0,  mid));
		int []rightData=mergeSort(Arrays.copyOfRange(a, mid,  a.length));
		a= merge(leftData,rightData);
		return a;
		
		}
	}
	
	public static void swap(int []a)
	{
		int temp=a[0];
		a[0]=a[1];
		a[1]=temp;
		
		
	}
	public static int[] merge(int []a, int []b)
	{
		int i=0;
		int j=0;
		int k=0;
		int []data=new int[a.length+b.length];
		while(i<a.length  && j< b.length)
		{
			if(a[i]<b[j])
			{
				data[k]=a[i];
				i++;
			}
			else
			{
				data[k]=b[j];
				j++;
			}
			k++;
		}
		for(int p=i;p<a.length;p++)
		{
			data[k]=a[p];
			k++;
		}
		for(int p=j;p<b.length;p++)
		{
			data[k]=b[p];
			k++;
		}
		return data;
	}
}
