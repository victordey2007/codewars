package codewars;

public class QuickSort {
	public static void main(String[] args) {
		int [] a= {0,5,1,4,2,6,3};
		
		quicksort(0,a.length-1,a)	  ;
		System.out.println(a);
	
	}              
	public static void  quicksort(int l,int k,int [] data)
	{
		if(l<k)
			{
			int f=partionning( l, k, data);
			//lef 
			if(f!=l)
			{quicksort(l,f,data);
			quicksort(f+1,k,data);
			}
			}
	}
	public static int  partionning(int l,int k,int [] data)
	{
		
		int i=l;
		int j=k;
		int pivot=data[i];
		
		while(i<=j)
		{
			if( data[j]<pivot && data[i]>pivot  )
			 {
				int temp=data[i];
				data[i]=data[j];
				data[j]=temp;
			 }
			
				
			if(data[i]>=pivot)
					i++; 
			 if(data[j]<=pivot )
				j--; 
			 
			 
		}
		if(data[l] >data[j])
		{int temp=data[l];
		data[l]=data[j];
		data[j]=temp;
		}
		return j;
	}
}
