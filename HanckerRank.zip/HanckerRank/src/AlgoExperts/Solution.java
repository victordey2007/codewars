package AlgoExperts;




import java.io.*;
import java.util.*;

public class Solution {
  public static void main(String[] argv) {
    String[] counts = {
      "900,google.com",
      "60,mail.yahoo.com",
      "10,mobile.sports.yahoo.com",
      "40,sports.yahoo.com",
      "300,yahoo.com",
      "10,stackoverflow.com",
      "20,overflow.com",
      "5,com.com",
      "2,en.wikipedia.org",
      "1,m.wikipedia.org",
      "1,mobile.sports",
      "1,google.co.uk"
    };
    
  @SuppressWarnings("unused")
HashMap<String,Integer>  map=  calculateClicksByDomain(counts);
 
    System.out.println(map);
  }
  
  public  static HashMap<String,Integer>  calculateClicksByDomain(String[] counts)
   {

    HashMap<String,Integer> map= new HashMap<String,Integer>();
     for(int i=0; i< counts.length;i++ )
    {
       String[] tokens1=counts[i].split(",");
       int count=Integer.valueOf(tokens1[0]);
       
       String[] tokens=tokens1[1].split("\\.");
       System.out.println(tokens[tokens.length-1]);
       
       
       String separator =".";
      
     
       
       if(tokens1[1].contains("."))
       {
    	   int sepPos = tokens1[1].lastIndexOf(separator); 
    	   
    	   String prefixKey= tokens1[1].substring(0,sepPos);
    	   insertIntoMap(map,prefixKey,count);
    	   String sufixKey= tokens1[1].substring(sepPos+1,tokens1[1].length());
    	   insertIntoMap(map,sufixKey,count);
    	   
    	   
       }
       else
       {
    	   insertIntoMap(map,tokens1[1],count);
       }
       
       
    
      
       
  
    }
     
    return  map;
          
  }
  
  @SuppressWarnings("unlikely-arg-type")
public  static void insertIntoMap(  HashMap<String,Integer> map,String key,int count)
  {
	  
	  if(map.containsKey(key))
      {
        int tempCount= map.get(key);
        map.put(key,tempCount+count);
          
       }
      else
      {
          map.put(key,count);
      }
  }
  
}
