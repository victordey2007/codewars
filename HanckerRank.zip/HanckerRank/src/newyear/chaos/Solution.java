package newyear.chaos;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class Solution {

    // Complete the minimumBribes function below.
static void minimumBribes(int[] a) {
       
        int [] sortArray=Arrays.copyOf(a, a.length);
        Arrays.sort(sortArray)         ;
        int count=0;
        for(int i=0;i<a.length;i++)
        {
            int index=binarySearchSort(sortArray,0,sortArray.length,a[i]);
            if(index-i>=2 || i-index>=2 )
            {
                 System.out.println("Too chaotic");
                 return;
            }
            if(index-i>0)
                count=count+(index-i);
            else if(i-index>0)
                count=count+(i-index);
                
            
                
        }
       System.out.println(count);
   

    }

    
    public static  int binarySearchSort(  int[] items, int startIndex,int endIndex,int searchItem)
      {
          
         
         
          
          if(items!=null && items.length>=endIndex && endIndex>=startIndex)
          {
              int mid=(endIndex-startIndex)/2+startIndex;
            
              if(items[mid]==searchItem)
                  return mid;
              else if(searchItem < items[mid])
                  return binarySearchSort(items,startIndex,mid,searchItem);
              else 
                  return  binarySearchSort(items,mid,items.length,searchItem);
          }
          
          return -1;
      }
    

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int t = scanner.nextInt();
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

        for (int tItr = 0; tItr < t; tItr++) {
            int n = scanner.nextInt();
            scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

            int[] q = new int[n];

            String[] qItems = scanner.nextLine().split(" ");
            scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

            for (int i = 0; i < n; i++) {
                int qItem = Integer.parseInt(qItems[i]);
                q[i] = qItem;
            }

            minimumBribes(q);
        }

        scanner.close();
    }
}
