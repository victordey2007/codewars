package codewars;

public class Permutations {

public static void main (String str[])
{
	String s="ABCD";
	int n=s.length();
	Permutations perm1= new Permutations();
	perm1.calculate(s,0,n-1);
	
}
private void calculate(String str,int left,int right)
{
if(left==right)
	System.out.println(str);
else
{
	for(int i=left;i<=right;i++)
	{
		String swapped=this.swap(str,left,i);
		this.calculate(swapped, left+1, right);
	}
}
	
}
private String swap(String str, int i, int j) {
	// TODO Auto-generated method stub
	char temp;
	char []charArray=str.toCharArray();
	temp=charArray[i];
	charArray[i]=charArray[j];
	charArray[j]=temp;
	return String.copyValueOf(charArray);
}
}