package codewars;

import java.util.*;

class HeapSort {
  public static int[] heapSort(int[] array) {
    // Write your code here.
     
    int left=0;
	int sortPos =array.length-1;
	prinnt(array);
		while(left<sortPos)
		{
			getMaxHeap(array,sortPos);
			int temp=array[0];
			array[0]=array[sortPos];
			array[sortPos]=temp;
			sortPos--;
		
		}
		
		
		
		return array;
  }
	
	public static void getMaxHeap(int[] array,int lastPos)
	{
		
	System.out.println((lastPos/2)-1);
		for(int i=(lastPos/2)-1 ;i>=0;i--)
		{
			int left=i*2+1;
			int right =i*2+2;
			if(array[left]> array[i])
			{
				int temp=array[i];
				array[i]=array[left];
				array[left]=temp;
			}				
			if(right<=lastPos && array[right]> array[i])
			{
				int temp=array[i];
				array[i]=array[right];
				array[right]=temp;
			
			}
			
			
		}
		prinnt(array);
		
	}
	
	public static void prinnt(int[] array)
	{
		for(int a:array)
		{
			System.out.print(a+":");
		}
		System.out.println("");
	}
}

