package AlgoExperts;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Do

public class TestMap {
	
	public static void main(String Str[])
	{ 
		
		HashSet<String> set=new HashSet<String>();
		
		set.add("VICTOR");
		set.add("VICTOR");
		set.add("LIPIKA");
		
		set.
		
		HashMap <Integer,String > map = new HashMap<Integer,String>();
		
		map.put(10,"Victor1");
		map.put(11,"Victor2");
		map.put(12,"Victor3");
		map.put(13,"Victor4");
		
 Integer.m
	for(int i:map.keySet())
	{
		
		System.out.println(map.get(i));
	}
	}

}
