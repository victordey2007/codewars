package codewars;
import java.util.*;
public class DnaStrand {
  public static String makeComplement(String dna) {
    //Your code
    
    HashMap<String,String> map=new HashMap<String,String>();
    map.put("A","T");
    map.put("T","A");
    map.put("C","G");
    map.put("G","C");
    
    String response="";
    
    for(int i=0;i<dna.length();i++)
    {
      String key=String.valueOf(dna.charAt(i));
      
      if(map.containsKey(key))
        {
          response=response+String.valueOf(map.get(key));
      
         }
       else
         {
          response=response+String.valueOf(key);
       }
      
    
    }
    
    return response;
    
  }
}