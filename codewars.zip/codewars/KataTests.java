package codewars;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import org.junit.runners.JUnit4;

public class KataTests {
    @Test
    public void basicTests() {
         assertEquals(239394299002988L, KatanextSmaller.nextSmaller(239394299008289L));
         assertEquals(790, KatanextSmaller.nextSmaller(907));
         assertEquals(513, KatanextSmaller.nextSmaller(531));
         assertEquals(-1, KatanextSmaller.nextSmaller(1027));
         assertEquals(414, KatanextSmaller.nextSmaller(441));
         assertEquals(123456789, KatanextSmaller.nextSmaller(123456798));
    }      
}