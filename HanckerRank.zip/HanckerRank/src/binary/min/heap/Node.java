package binary.min.heap;

public class Node {
	public Node getTop() {
		return top;
	}

	public void setTop(Node top) {
		this.top = top;
	}

	private int key;
	int position;
	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	private Node top,left,right;
	
	public Node()
	{
		
	}
	
	public Node(int key)
	
	{
		this.key=key;
		this.left=this.right=null;
		
	}

	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}

	public Node getLeft() {
		return left;
	}

	public void setLeft(Node left) {
		this.left = left;
	}

	public Node getRight() {
		return right;
	}

	public void setRight(Node right) {
		this.right = right;
	}
	
}


