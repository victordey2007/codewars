package codewars;

public class LongestPalindromicSusbstring {
	public static void main(String str[]) {
		longestPalindromicSubstring("z234a5abbba54a32z");
	}

	public static String longestPalindromicSubstring(String str) {
		// Write your code here.
		String respose = "";
		if (str.length() <= 1)
			return str;

		char[] letters = str.toCharArray();
		for (int i = 1; i < letters.length; i++) {

			String evenPalim = isTheStringPalindromic(str, i,i+1);
			String oddPalim = isTheStringPalindromic(str, i-1,i+1);
			if (evenPalim.length()>oddPalim.length() && evenPalim.length()>respose.length())
				respose = evenPalim;
			else if(oddPalim.length()>evenPalim.length() && oddPalim.length()>respose.length())
				respose = oddPalim;
		}

		System.out.println(respose);

		return respose;
	}

	public static String isTheStringPalindromic(String str, int left ,int right) {
		String resp = "";
	
		char[] letters=str.toCharArray();
		while (left>=0 && right<str.length() ) {
			if (letters[left] != letters[right])
				return resp;
			else {

				resp = str.substring(left, right + 1);
				left--;
				right++;
			}
		}

		return resp;

	}
}
