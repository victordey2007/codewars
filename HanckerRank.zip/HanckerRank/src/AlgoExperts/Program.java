package AlgoExperts;

import java.util.*;

class Program {
  // Tip: You can use `element instanceof ArrayList` to check whether an item
  // is an array or an integer.
  public static <K, V> int productSum(List<Object> array) {
    // Write your code here.
	  array.remove(0);
	  HashMap<K, V> ls;
	  ls.
	  
   	int temp=0;
		for(Object data:array)
		{
			if(data instanceof Integer)
			{
				int dataInt=(Integer)data;
				temp=temp+dataInt;
			}
			else
			{
			temp=temp+productSumEachElement(data,2);
			}
		}
		return temp;
		
		
	}
	 public static int productSumEachElement(Object array,int depth) {
		int temp=0;
		List<Integer> tempData=(List<Integer>)array;
		for(Object data:tempData)
		{
			if(data instanceof Integer)
			{
				int dataInt=(Integer)data;
				temp=temp+(depth*dataInt);
			}
			else
			{
			depth++;
			temp=temp+productSumEachElement(data,depth);
		
			}
		}
		 return temp;
		 
	 }
}
