package codewars;

public class QuickSelect {
public static void main(String[] args) {
	int [] a= {0, 1, 21, 33, 45, 45, 45, 45, 45, 45, 61, 71, 73};
	searchForRange(a,-1);
}

public static int [] searchForRange(int[] array, int k) {
    // Write your code here.
    int []val= {-1,-1};
    quickselect(0,array.length-1,k,array,val);
    System.out.println(val[0]);
    System.out.println(val[1]);
    return val;
  }

private static void quickselect(int i, int j, int target, int[] array, int[] val) {
	// TODO Auto-generated method stub
	if(i>j)
		return;
	
	if(i==j)
	{
		if(array[i]==target)
		{
			setIndexX(val,i);
			setIndexY(val,i);
		}
		return ;
	}
	int mid=(i+j)/2;
	
	if(array[mid]>target)
	{
		quickselect(i,mid-1,target,array,val);
		
	}
	else if(array[mid]<target)
	{
		quickselect(mid+1,j,target,array,val);
		
	}
	else {
		setIndexX(val,mid);
		setIndexY(val,mid);
		if(mid>0 && array[mid-1]==target)
		{
			if(mid-1>i)
				quickselect(i,mid-1,target,array,val);
			else 
				setIndexX(val,mid-1);
		}
		
		if(array[mid+1]==target)
		{
			if(mid<j && mid+1<j)
				quickselect(mid+1,j,target,array,val);
			else 
				setIndexY(val,mid+1);
		}

	}
		


	
}
public static void  setIndexX(int[] val,int postion)
{
	if(val[0]==-1||val[0]>postion )
		val[0]=postion;
}
public static void  setIndexY(int[] val,int postion)
{
	if(val[1]==-1||val[1]<postion )
		val[1]=postion;
}

}
