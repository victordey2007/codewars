package codewars;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.IntStream;

public class Interval {

	
	public static int sumIntervals(int[][] intervals) {
        return intervals == null ? 0 : (int) Arrays.stream(intervals)
            .flatMapToInt(interval -> IntStream.range(interval[0], interval[1]))
            .distinct()
            .count();
    }
	
	
	/*
	 * public static int sumIntervals(int[][] intervals) { // TODO: implement this
	 * method
	 * 
	 * if(intervals==null || intervals.length<=0) return 0;
	 * 
	 * int length=0; java.util.Arrays.sort(intervals, new
	 * java.util.Comparator<int[]>() { public int compare(int[] a, int[] b) { return
	 * Double.compare(a[0], b[0]); } });
	 * 
	 * int pos=0; ArrayList<List<Integer>>IntervalData= new
	 * ArrayList<List<Integer>>();
	 * 
	 * 
	 * for(int i=0;i<intervals.length;i++) { if(i==0) { List<Integer> data=new
	 * ArrayList<Integer>(); data.add(intervals[i][0]);// add start
	 * data.add(intervals[i][1]);// add start IntervalData.add(data);
	 * 
	 * } else if(intervals[i][0]>=IntervalData.get(pos).get(0) && intervals[i][0] <=
	 * IntervalData.get(pos).get(1) || intervals[i][1]>=IntervalData.get(pos).get(0)
	 * && intervals[i][1] <= IntervalData.get(pos).get(1) ) { if(intervals[i][1] >
	 * IntervalData.get(pos).get(1)) { IntervalData.get(pos).set(1,intervals[i][1]);
	 * }
	 * 
	 * 
	 * } else { List<Integer> data=new ArrayList<Integer>();
	 * data.add(intervals[i][0]);// add start data.add(intervals[i][1]);// add start
	 * IntervalData.add(data); pos=pos+1; }
	 * 
	 * 
	 * } for(List<Integer> data1:IntervalData) {
	 * length=length+data1.get(1)-data1.get(0); } System.out.println(IntervalData);
	 * return length; }
	 * 
	 */
}
