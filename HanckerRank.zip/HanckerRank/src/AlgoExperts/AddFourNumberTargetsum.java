package AlgoExperts;

import java.util.*;

class AddFourNumberTargetsum {
	
	
public static void main(String str[])
{
	int [ ] a= {5, -5, -2, 2, 3, -3};
	int targetsum=0;
	List<Integer[]>  result=fourNumberSum(a,targetsum);
	int a1=0;
	int b=-7;
	System.out.println(a1-b);
	System.out.println(result);
}
public static List<Integer[]> fourNumberSum(int[] array, int targetSum) {
    // Write your code here.
			HashMap<Integer, Integer> dataMap = new HashMap<Integer, Integer>();
		    Arrays.parallelSort(array);
		    
		ArrayList<Integer[]> respose = new ArrayList<Integer[]>();
		for (int l = 0; l < array.length; l++)
			dataMap.put(array[l], l);
		for (int i = 0; i < array.length-1; i++) {
			ArrayList<Integer> internalList=null;
			for (int j = i+1; j < array.length; j++) {
				
				for(int k=j+1;k<array.length;k++)
				{
		
					internalList = new ArrayList<Integer>();
					internalList.add(array[i]);
					internalList.add(array[j]);
					internalList.add(array[k]);
					int temp = targetSum - (internalList.get(0) + internalList.get(1)+internalList.get(2));
					System.out.println(internalList.get(0) + ":" + internalList.get(1) + ":" +internalList.get(1)+":"+ temp);
					if (dataMap.get(temp) != null && dataMap.get(temp)>k ) {
						internalList.add(temp);
						Integer[] arr = new Integer[internalList.size()];
						arr = internalList.toArray(arr);
						Arrays.sort(arr);
						respose.add(arr);
						System.out.println("FFFF");
						
					}
				}
			}
			

		}
		return respose;
  }

}
