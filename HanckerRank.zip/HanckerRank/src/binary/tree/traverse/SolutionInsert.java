package binary.tree.traverse;

public class SolutionInsert {

	public static void main(String str[]) {
		int[] data = { 1000, 12, 3, 100, 300, 500, 600 };

		Node root =new Node(data[0]);;
		for(int i=1;i<data.length;i++)
		{
			buildOridinaryHeapFromArray(root, data[i]);
		}
		
		System.out.println(root);
	}

	//  left<=root and right > root
		public static void buildOridinaryHeapFromArray(Node root, int data1) {
		Node node1 = null;

	
		node1 = new Node(data1);
			
		System.out.println(data1);
		
		

		if (data1 <= root.getKey() && root.getLeft() == null) {
			root.setLeft(node1);
			return ;
			
		} else if (data1 <= root.getKey() && root.getLeft() != null) {
			buildOridinaryHeapFromArray(root.getLeft(), data1);
			return ;

		} else if (data1 > root.getKey() && root.getRight() == null)
		{
			root.setRight(node1);
			return ;
		}
		else if (data1> root.getKey() && root.getRight() != null)
			{
			buildOridinaryHeapFromArray(root.getRight(), data1);
			return ;
			}
		
		
		
	}
		
}
