package codewars;
/*
 * accum("abcd") -> "A-Bb-Ccc-Dddd"
accum("RqaEzty") -> "R-Qq-Aaa-Eeee-Zzzzz-Tttttt-Yyyyyyy"
accum("cwAt") -> "C-Ww-Aaa-Tttt"
 */
public class Accumul {
	public static void main(String str[])
	{
String tt="aba";		
StringBuilder data=new StringBuilder(tt);
System.out.println(tt.equals(data));

	}
    
    public static String accum(String s) {
   
     // your code
   String response="";
      for(int i=0;i<s.length();i++)
        {
            int aschii=s.charAt(i);
            
           if(aschii>=97 && aschii<=122 )
                 aschii=aschii-32;
          if(i!=0)
           response= response+"-"+prepareString((char)aschii,i);
          else
            response= response+prepareString((char)aschii,i);
      }
      System.out.println(response);
      return response;
    }
  
  public static String prepareString(char startChar,int count)
    {
      String text= String.valueOf(startChar);
      int newAschi=startChar+32;
      char newChar=(char)newAschi;
      for(int i=0;i<count;i++)
        text=text+String.valueOf(newChar);
  
    return text;
  }
}