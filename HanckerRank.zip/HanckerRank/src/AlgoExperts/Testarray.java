package AlgoExperts;


import java.util.*;

public class Testarray {
	
	
	
	public static void main (String str[]) throws Throwable
	{	 
		
		System.out.println(Integer.valueOf(String.valueOf('4')));;
		
		System.out.println("ABC".substring(0, 2));
	}

	public static List <List<Integer>> getListSequence(Integer [] input)
	{
		
		
		List <List<Integer>> response =new ArrayList <List<Integer>>();
		
		
		
			
		if(input.length<=1)
		{
			
			List<Integer> temp=Arrays.asList(input);
			response.add(temp);
			return response;
			
			
		}
			Arrays.sort(input);
		List<Integer> temp=new ArrayList<>();
		//temp.add(input[0]);
		
		int start =0;
		for(int i=0;i<input.length;i++)
		{
			if(i==0)
				temp.add(input[i]);
			else if(input[i]-input[i-1]==1)
			{
				temp.add(input[i]);
				
			}
			else
			{
				response.add(temp);
				temp=new ArrayList<>();
				temp.add(input[i]);
			}
			
		}
		response.add(temp);
		return response;
		
	}
	public static List <List<Integer>> getListSequence1(Integer [] input)
	{
		HashMap<Integer,Boolean> map=new HashMap<Integer,Boolean>();
		List <List<Integer>>  response=new ArrayList <List<Integer>>();
		for(Integer data:input)
			map.put(data,false);
		
		int k=0;
		for(Integer data:input)
		{
			k++;
			if(!map.get(data))
				
			{
			List<Integer> temp=new ArrayList<Integer>();
			temp.add(data);
			boolean flag=true;
			int left=data-1;
			int right =data+1;
			while(flag)
			{
				k++;
				if(!map.containsKey(left)  && !map.containsKey(right)  )
					break;
				
				if(map.get(left)!=null && !map.get(left)) {
					
					temp.add(left);
					map.put(left,true);
					left--;
					
				}
				if(map.get(right)!=null && !map.get(right)) {
					
					temp.add(right);
					map.put(right,true);
					right++;
				}
					
				
				
			}
			response.add(temp);
			}
		
		}
		System.out.println(k);
		return response;
		
		
		
	}
}
