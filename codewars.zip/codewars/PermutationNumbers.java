package codewars;

import java.util.ArrayList;

public class PermutationNumbers {
	  
	public static void main(String str[])
	{
	int number=1233;
    ArrayList<Integer> data=new ArrayList<Integer>();
    
	getAllCombination(number,0,data);
	System.out.println(data);
	}
	
	


private static void getAllCombination(int number, int i, ArrayList<Integer> data) {
		// TODO Auto-generated method stub
			
		if(i == String.valueOf(number).length()-1)
		{	
			data.add(number);
			return ;
		}
		
		for(int l=i;l<String.valueOf(number).length();l++)
		{
			int temp=swap(number,i,l);
			getAllCombination(temp,i+1,data);
			
		}
		
	}




public static int swap(int input,int i,int j)
{
  char[] digits=String.valueOf(input).toCharArray();	
   
  char temp=digits[i];
  digits[i]=digits[j];
  digits[j]=temp;
  
  return Integer.parseInt(String.valueOf(digits));
}

}