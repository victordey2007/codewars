package codewars;

import java.util.*;

public class SumSquaredDivisors {
	public  static Integer[] bringTheBiggesElement(Integer [] digits,int j)
    {
    Integer[] data=new Integer[digits.length];
    
    for(int i=0;i<=j;i++)
      data[i]=digits[i];
     Integer[] data1=Arrays.copyOfRange(digits,j+1,digits.length);
     Arrays.sort(data1);
     for(int i=0;i<data1.length;i++)
      data[i]=data1[i];
    return data;    
    
  }
	
	public static String listSquared(long m, long n) {
		ArrayList<String> resp=new 	ArrayList<String>();
    for(long i=m;i<=n;i++)
      {
      Long   data=getAllDivisorSum(i);
      Double sqr=(Double)Math.sqrt(data);
     
      if(sqr==Math.round(sqr))
       { resp.add("["+ i+", "+data+"]");
        }
        
    }
   
  
    return resp.toString();
	}
  
  
  public static Long  getAllDivisorSum(long number)
    {
    Long sum=0L;
    long i=1;
    while(i<=number)
      {
      if(number%i==0)
     	  sum=sum+i*i;
       i++;
      }
    return sum;
  }
  
	/*
	 * public static long getSumAllDivisor( long n) { return LongStream.range(1,
	 * n+1).filter(i-> n%i==0).map(i->i*i).sum();
	 * 
	 * }
	 */
}

