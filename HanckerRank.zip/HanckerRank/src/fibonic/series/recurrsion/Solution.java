package fibonic.series.recurrsion;

public class Solution {

	static void  fib(int n) 
    { 
		int prev=0;
		int current=1;
	System.out.print(0+" ");
	for(int i=1;i<=n;i++)
	{
	 int next=prev+current;
		System.out.print(next+" ");
		prev=current;
		current=next;
	}
    } 
	static void fib1(int n,int index ,int prev,int curr) 
	{
		if(index>n)
			return ;
		if(index==1)
			System.out.print(0+" ");
		index++;
		System.out.print((prev+curr) +" ");
		fib1(n,index,curr,(prev+curr));
		
	}
	
    public static void main (String args[]) 
    { 
    int n = 9; 
    fib(n); 
    
    System.out.println("%%%%%%%%%%%%%%");
    fib1(n,1,0,1); 
    } 
}
