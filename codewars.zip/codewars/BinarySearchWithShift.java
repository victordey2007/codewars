package codewars;

public class BinarySearchWithShift {
public static void main(String[] args) {
	 int [] a= {20,21,22,23,24,1,3,4,5};
	 int target=3;
	 
	
}

public static int  BinarySearchWithShift(int []a , int target,int i,int j)
{
	if(i>j)
		return -1 ;
	
	int mid=i+j/2;
	if(a[mid]==target)
		return mid;
	 if(a[i]==target)
		return i;
	if(a[j]==target)
		return j;
	
	// expected binary condition
	if(target>a[mid] && a[mid]<a[j] && target< a[j])
	{
		return BinarySearchWithShift(a,target,mid+1,j-1);
		
	}
	// expected binary condition
	if(target< a[mid]&& a[mid]>a[i]  && target> a[i])
	{
		return BinarySearchWithShift(a,target,i+1,mid-1);
		
	}
	if(target>a[mid] && a[mid]<a[j])
	{
		return BinarySearchWithShift(a,target,mid+1,j-1);
		
	}
	if(target<a[mid] && a[mid]<a[j])
	{
		return BinarySearchWithShift(a,target,mid+1,j-1);
		
	}
}


}
